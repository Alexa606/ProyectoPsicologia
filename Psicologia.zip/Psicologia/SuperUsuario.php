
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content = "IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMINISTRADOR</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" 
    integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" 
    crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    <link rel="stylesheet" type="text/css" href="estiloC.css">
    
</head>
<body>
<a href="home.html" class="menu-link">MENU</a>
<form method="POST" action="conexionsSuperUsu.php"  >

                <h4>FORMULARIO ADMINISTRADOR</h4>
                
    <div class = "input-group">
    
    <div class = "input-container">
        <input type="text" name="CLAVE_SU" placeholder = "Numero de control">
        <i class = "fa-solid fa-id-card-clip" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="NOMBRE" placeholder = "Nombre">
        <i class = "fa-solid fa-user" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="A_PATERNO" placeholder = "Apellido paterno">
        <i class = "fa-solid fa-user" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="A_MATERNO" placeholder = "Apellido Materno">
        <i class = "fa-solid fa-user" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="CORREOE" placeholder = "Correo">
        <i class = "fa-solid fa-at" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="CONTRASENA" placeholder = "Nueva contraseña">
        <i class = "fa-solid fa-key" ></i>
    </div>
    <input class="botons" type="submit" name = "RegistrarUSUARIO" value="Registrar Usuario">
    <br><br>
    <input class="botons" type="submit" name = "ActualizarUSUARIO" value="Actualizar Usuario">
    <br><br>
    <input class="botons" type="submit" name ="EliminarUSUARIO" value="Eliminar Usuario">
    
    </div>
    </form>

</body>
</html>