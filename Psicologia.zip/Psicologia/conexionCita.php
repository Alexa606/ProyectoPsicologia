<?php
header('Content-Type: text/html; charset=UTF-8');
$CLAVE_CITA = $_POST['CLAVE_CITA'];
$FECHA_HORA = $_POST['FECHA_HORA'];
$LUGAR = $_POST['LUGAR'];
$CORREO_INSTITUCIONAL= $_POST['CORREO_INSTITUCIONA'];
$NO_CONTROL_ALUMNO = $_POST['NO_CONTROL_ALUMNO'];
$CLAVECONSULTA = $_POST['CLAVECONSULTA'];

$conexion = new mysqli("127.0.0.1", "root", "", "psicologa");
$conexion->set_charset("utf8");

if ($conexion->connect_error) {
    die("Error de conexión a la base de datos: " . $conexion->connect_error);
}

if (isset($_POST['RegistrarCITA'])) {
    $consulta = "INSERT INTO CITA (CLAVE_CITA, FECHA_HORA, LUGAR, CORREO_INSTITUCIONAL, NO_CONTROL_ALUMNO, CLAVECONSULTA)
                VALUES (?, ?, ?, ?, ?, ?)";

    $stmt = $conexion->prepare($consulta);

    if ($stmt) {
        $stmt->bind_param("ssssss", $CLAVE_CITA, $FECHA_HORA, $LUGAR, $CORREO_INSTITUCIONAL, $NO_CONTROL_ALUMNO, $CLAVECONSULTA);

        if ($stmt->execute()) {
            echo "La cita se registró con éxito.";
        } else {
            echo "Error al dar de alta: " . $stmt->error;
        }

    } else {
        echo "Error en la preparación de la consulta: " . $conexion->error;
    }
}

if (isset($_POST['ActualizarCITA'])) {
    $consulta = "UPDATE CITA 
        SET FECHA_HORA = ?, LUGAR = ?, CORREO_INSTITUCIONAL = ?, NO_CONTROL_ALUMNO = ?, CLAVECONSULTA = ?
        WHERE CLAVE_CITA = ?";

    $stmt = $conexion->prepare($consulta);

    if ($stmt) {
        $stmt->bind_param("ssssss", $FECHA_HORA, $LUGAR, $CORREO_INSTITUCIONAL, $NO_CONTROL_ALUMNO, $CLAVECONSULTA, $CLAVE_CITA);

        if ($stmt->execute()) {
            echo "La actualización se realizó con éxito.";
        } else {
            echo "Error al actualizar la cita: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error en la preparación de la consulta: " . $conexion->error;
    }
}

if (isset($_POST['EliminarCITA'])) {
    $consulta = "DELETE FROM CITA
        WHERE CLAVE_CITA = ?";

    $stmt = $conexion->prepare($consulta);

    if ($stmt) {
        $stmt->bind_param("s", $CLAVE_CITA);

        if ($stmt->execute()) {
            echo "La cita se eliminó con éxito.";
        } else {
            echo "Error al eliminar la cita: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error en la preparación de la consulta: " . $conexion->error;
    }
}

$conexion->close();
?>
