<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Resultados de la Consulta</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="ConsultaS.css">
    <link rel="stylesheet" type="text/css" href="estilo.css">
</head>
<body>
<a href="home.html" class="menu-link">MENU</a>
    <div class="input-container">
        <h2>ALUMNOS CON SUS CARRERAS</h2>
        <table class="styled-table">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Apellido Paterno</th>
                    <th>Apellido Materno</th>
                    <th>Carrera</th>
                </tr>
            </thead>
            <tbody>
            <?php
                // Conexión a la base de datos Oracle
                $conn = oci_connect("system", "M4r4lex89", "localhost/xe");

                if (!$conn) {
                    $error = oci_error();
                    echo "Error de conexión: " . $error['message'];
                } else {
                    // Ejecutar la consulta SQL
                    $sql = "SELECT A.NOMBRE, A.A_PATERNO, A.A_MATERNO, C.CARRERA FROM ALUMNO A JOIN CARRERA C ON A.CLAVECARRERA = C.CLAVECARRERA";
                    $stid = oci_parse($conn, $sql);
                    oci_execute($stid);

                    // Continuar el código PHP después de la conexión
                    while ($row = oci_fetch_assoc($stid)) {
                        echo '<tr>';
                        echo '<td>' . $row['NOMBRE'] . '</td>';
                        echo '<td>' . $row['A_PATERNO'] . '</td>';
                        echo '<td>' . $row['A_MATERNO'] . '</td>';
                        echo '<td>' . $row['CARRERA'] . '</td>';
                        echo '</tr>';
                    }

                    oci_free_statement($stid);
                    oci_close($conn);
                }
            ?>

            </tbody>
        </table>
    </div>
</body>
</html>
