<?php
header('Content-Type: text/html; charset=UTF-8');
$NO_CONTROL = $_POST['NO_CONTROL'];
$NOMBRE = $_POST['NOMBRE'];
$A_PATERNO = $_POST['A_PATERNO'];
$A_MATERNO = $_POST['A_MATERNO'];
$F_NACIMIENTO = $_POST['F_NACIMIENTO'];
$EDAD = $_POST['EDAD'];
$TELEFON = $_POST['TELEFONO'];
$CORREO_INST = $_POST['CORREO_INST'];
$GENERO = $_POST['GENERO'];
$GRUPO = $_POST['GRUPO'];
$TURNO = $_POST['TURNO'];
$SEMESTRE = $_POST['SEMESTRE'];
$CLAVE_DIRECCION = $_POST['CLAVE_DIRECCION'];
$CLAVECARRERA = $_POST['CLAVECARRERA'];

$conexion = new mysqli("127.0.0.1", "root", "", "psicologa");
$conexion->set_charset("utf8");

if ($conexion->connect_error) {
    die("Error de conexión a la base de datos: " . $conexion->connect_error);
}

if (isset($_POST['RegistrarALUMNO'])) {
    $consulta = "INSERT INTO ALUMNO (NO_CONTROL, NOMBRE, A_PATERNO, A_MATERNO, F_NACIMIENTO, EDAD, TELEFON, 
        CORREO_INST, GENERO, GRUPO, TURNO, SEMESTRE, CLAVE_DIRECCION, CLAVECARRERA)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conexion->prepare($consulta);

    if ($stmt) {
        $stmt->bind_param("issssisssssiii", $NO_CONTROL, $NOMBRE, $A_PATERNO, $A_MATERNO, $F_NACIMIENTO, $EDAD, $TELEFON,
            $CORREO_INST, $GENERO, $GRUPO, $TURNO, $SEMESTRE, $CLAVE_DIRECCION, $CLAVECARRERA);

        if ($stmt->execute()) {
            echo "El alumno se registró con éxito.";
        } else {
            echo "Error al dar de alta: " . $stmt->error;
        }

    } else {
        echo "Error en la preparación de la consulta: " . $conexion->error;
    }
}

if (isset($_POST['ActualizarALUMNO'])) {
    $consulta = "UPDATE ALUMNO
        SET NOMBRE = ?, A_PATERNO = ?, A_MATERNO = ?, F_NACIMIENTO = ?, EDAD = ?, TELEFON = ?, 
        CORREO_INST = ?, GENERO = ?, GRUPO = ?, TURNO = ?, SEMESTRE = ?, CLAVE_DIRECCION = ?, CLAVECARRERA = ?
        WHERE NO_CONTROL = ?";
    
    $stmt = $conexion->prepare($consulta);
    
    if ($stmt) {
        $stmt->bind_param("sssssisssssiii", $NOMBRE, $A_PATERNO, $A_MATERNO, $F_NACIMIENTO, $EDAD, $TELEFON,
            $CORREO_INST, $GENERO, $GRUPO, $TURNO, $SEMESTRE, $CLAVE_DIRECCION, $CLAVECARRERA, $NO_CONTROL);
    
        if ($stmt->execute()) {
            echo "El alumno se actualizó con éxito.";
        } else {
            echo "Error al actualizar: " . $stmt->error;
        }
    
        $stmt->close();
    } else {
        echo "Error en la preparación de la consulta: " . $conexion->error;
    }
}


if (isset($_POST['EliminarALUMNO'])) {
    $consulta = "DELETE FROM ALUMNO
        WHERE NO_CONTROL = ?";
    $stmt = $conexion->prepare($consulta);

    if ($stmt) {
        $stmt->bind_param("i", $NO_CONTROL);
        if ($stmt->execute()) {
            echo "El alumno se eliminó con éxito.";
        } else {
            echo "Error al eliminar al alumno." . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error de conexión a la base de datos: " . $conexion->error;
    }
}

$conexion->close();
?>
