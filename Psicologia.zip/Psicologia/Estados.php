
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content = "IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ESTADO</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    
    <link rel="stylesheet" type="text/css" href="estilo.css">
    
</head>
<body>
<a href="HomeTutor.html" class="menu-link">MENU</a>
    
<form method="POST" action="conexionEstado.php"  >
                <h4>FORMULARIO ESTADO</h4>
    <div class = "input-group">
   
    <div class = "input-container">
        <input type="text" name="CLAVE_ESTADO" placeholder = "Clave">
        <i class = "fa-solid fa-id-card-clip" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="RIESGO" placeholder = "Riesgo">
        <i class = "fa-solid fa-circle-xmark" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="NECESIDADESPECIAL" placeholder = "Necesidad especial">
        <i class = "fa-solid fa-glasses" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="CANALIZADO" placeholder = "Canalizado">
        <i class = "fa-solid fa-check" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="DEJO_DE_ASISTIR" placeholder = "Dejo de asistir">
        <i class = "fa-solid fa-list" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="DUAL" placeholder = "Dual">
        <i class = "fa-solid fa-building" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="ACCIONES" placeholder = "Acciones">
        <i class = "fa-solid fa-check" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="NO_CONTROL_A" placeholder = "No. control del alumno">
        <i class = "fa-solid fa-id-card-clip" ></i>
    </div>

    <input class="botons" type="submit" name = "RegistrarESTADO" value="Registrar estado">
    <br><br>
    <input class="botons" type="submit" name = "ActualizarESTADO" value="Actualizar estado">
    <br><br>
    <input class="botons" type="submit" name ="EliminarESTADO" value="Eliminar estado">
    
    </div>
    </form>

</body>
</html>