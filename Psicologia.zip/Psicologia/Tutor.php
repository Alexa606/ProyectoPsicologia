<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content = "IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TUTOR</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" type="text/css" href="estiloC.css">


</head>
<body>
<a href="home.html" class="menu-link">MENU</a>
    
<form method="POST" action="conexionTutor.php"  >
                <h4>FORMULARIO TUTOR</h4>
    <div class = "input-group">

   
    <div class = "input-container">
        <input type="text" name="CLAVETUTOR" placeholder = "Clave">
        <i class = "fa-solid fa-id-card-clip" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="NOMBRE" placeholder = "Nombre">
        <i class = "fa-solid fa-user" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="A_PATERNO" placeholder = "Apellido paterno">
        <i class = "fa-solid fa-user" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="A_MATERNO" placeholder = "Apellido Materno">
        <i class = "fa-solid fa-user" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="GENERO" placeholder = "Genero">
        <i class = "fa-solid fa-venus-mars" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="EDAD" placeholder = "Edad">
        <i class = "fa-solid fa-user" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="TELEFONOC" placeholder = "Número de Telefono">
        <i class = "fa-solid fa-mobile" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="CORREOE" placeholder = "Correo">
        <i class = "fa-solid fa-at" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="CLAVECARRERA" placeholder = "Clave de la carrera">
        <i class = "fa-solid fa-id-card-clip" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="CONTRASEÑA" placeholder = "Contraseña">
        <i class = "fa-solid fa-id-card-clip" ></i>
    </div>

    <input class="botons" type="submit" name = "RegistrarTUTOR" value="Registrar TUTOR">
    <br><br>
    <input class="botons" type="submit" name = "ActualizarTUTOR" value="Actualizar TUTOR">
    <br><br>
    <input class="botons" type="submit" name ="EliminarTUTOR" value="Eliminar TUTOR">
    
    </div>
    </form>

</body>
</html>